/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./basicUtility1.html"],
  darkMode: "class",
  theme: {
    extend: {
      spacing: {
        13: "3.25rem",
      },
      fontFamily: {
        inter: "Inter",
      },
      colors: {
        info: "#bada55",
      },
      animation: {
        "spin-slow": "spin 3s linear infinite",
        goyang: "wiggle 2s ease-in-out infinite ",
      },
      keyframes: {
        wiggle: {
          "0% ,100% ": { transform: "rotate(-15deg)" },
          "50%": { transform: "rotate(15deg)" },
        },
      },
    },
  },
  plugins: [],
};
